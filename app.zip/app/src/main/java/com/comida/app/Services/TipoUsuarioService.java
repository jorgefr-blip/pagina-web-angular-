package com.comida.app.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.comida.app.Entity.TipoUsuario;
import com.comida.app.Repository.TipoUsuarioRepository;



@RestController
@RequestMapping("/TipoUsuario")
@CrossOrigin
public class TipoUsuarioService {

	
	@Autowired()
    private TipoUsuarioRepository TipoUsuarioRepository ;
	
	@GetMapping("/buscar")
    public List<TipoUsuario> buscar() {
        return TipoUsuarioRepository.findAll();
    }
	
	@PostMapping("/guardar")
    public TipoUsuario guardar(@RequestBody TipoUsuario TipoUsuario) {
        return TipoUsuarioRepository.save(TipoUsuario);
    }
	@DeleteMapping(path="/eliminar/{idtipoUsuario}")
	public void eliminar(@PathVariable int idtipoUsuario) {
		TipoUsuarioRepository.deleteById(idtipoUsuario);
	}

}
