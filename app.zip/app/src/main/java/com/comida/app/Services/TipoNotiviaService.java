package com.comida.app.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.comida.app.Entity.TipoNoticia;
import com.comida.app.Repository.TipoNoticiaRepository;
@RestController
@RequestMapping("/tipoNoticia")
@CrossOrigin
public class TipoNotiviaService {

	
	
	 @Autowired()
	    private TipoNoticiaRepository TipoNoticiaRepository;
	 
	 @GetMapping("/buscar")
	    public List<TipoNoticia> buscar() {
	        return TipoNoticiaRepository.findAll();
	    }
	 
	  @PostMapping("/guardar")
	    public TipoNoticia guardar(@RequestBody TipoNoticia TipoNoticia) {
	        return TipoNoticiaRepository.save(TipoNoticia);
	    }
	 
	  @DeleteMapping(path="/eliminar/{idtipoNoticia}")
		public void eliminar(@PathVariable int idtipoNoticia) {
		  TipoNoticiaRepository.deleteById(idtipoNoticia);
		}
	 
}
