package com.comida.app.Entity;
import java.io.Serializable;

import jakarta.persistence.Basic;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.Table;

@Entity 
@Table(name="ingrediente")

public class ingrediente implements Serializable {

	private static final long serialVersionUID = 8924078664833851550L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name ="idingrediente")
	private Integer idingrediente;
	
	@Column(name ="nombre")
	private String nombre;
	
	@Column(name ="cantidad")
	private Integer cantidad;
	
	public Integer getIdingrediente() {
		return idingrediente;
	}

	public void setIdingrediente(Integer idingrediente) {
		this.idingrediente = idingrediente;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getCantidad() {
		return cantidad;
	}

	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}
	
}
