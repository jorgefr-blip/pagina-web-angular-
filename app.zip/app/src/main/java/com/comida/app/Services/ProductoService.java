package com.comida.app.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.comida.app.Entity.Producto;


@RestController
@RequestMapping("/producto")
@CrossOrigin
public class ProductoService {

	
	@Autowired()
    private com.comida.app.Repository.ProductoRepository ProductoRepository;
	
	
	@GetMapping("/buscar")
    public List<Producto> buscar() {
        return ProductoRepository.findAll();
    }
	
	 @PostMapping("/guardar")
	    public Producto guardar(@RequestBody Producto Producto) {
	        return ProductoRepository.save(Producto);
	    }
	 @DeleteMapping(path="/eliminar/{idproducto}")
		public void eliminar(@PathVariable int idproducto) {
		 ProductoRepository.deleteById(idproducto);
		}
	    
}
