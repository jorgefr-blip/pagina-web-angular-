package com.comida.app.Entity;

import java.io.Serializable;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table(name="tipo_administrador")
public class TipoAdministrador implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name ="idtipo_administrador")
	private Integer idtipoAdministrador;
	
	@Column(name ="descripcion")
	private String descripcion;
	
	@Column(name ="imagen")
	private String imagen;

	public Integer getIdtipoAdministrador() {
		return idtipoAdministrador;
	}

	public void setIdtipoAdministrador(Integer idtipoAdministrador) {
		this.idtipoAdministrador = idtipoAdministrador;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
	
}
