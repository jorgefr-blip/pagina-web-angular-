package com.comida.app.Repository;

import java.util.List; 

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.comida.app.Entity.ingrediente;

@Repository("ingredienteRepository")
public interface ingredienteRepository extends JpaRepository<ingrediente, Integer> {
	
public	List<ingrediente> findByNombreAndCantidad(String nombre, Integer cantidad);

public List<ingrediente> findByCantidad(Integer cantidad);
	
public	List<ingrediente> findByNombreLike(String nombre);

public	List<ingrediente> findByNombre(String nombre);
}
