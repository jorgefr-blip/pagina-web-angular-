package com.comida.app.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.comida.app.Entity.TipoNoticia;

@Repository("TipoNoticiaRepository")
public interface TipoNoticiaRepository extends JpaRepository<TipoNoticia, Integer>{

}
