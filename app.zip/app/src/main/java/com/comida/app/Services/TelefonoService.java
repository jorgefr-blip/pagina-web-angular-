package com.comida.app.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.comida.app.Entity.Telefono;
import com.comida.app.Repository.TelefonoRepository;



@RestController
@RequestMapping("/telefono")
@CrossOrigin
public class TelefonoService {

	
	 @Autowired()
	    private TelefonoRepository TelefonoRepository ;
	 
	 @GetMapping("/buscar")
	    public List<Telefono> buscar() {
	        return TelefonoRepository.findAll();
	    }
	 @PostMapping("/guardar")
	    public Telefono guardar(@RequestBody Telefono Telefono) {
	        return TelefonoRepository.save(Telefono);
	    }
	 
	 @DeleteMapping(path="/eliminar/{idtelefono}")
		public void eliminar(@PathVariable int idtelefono) {
		 TelefonoRepository.deleteById(idtelefono);
		}
	    
}
