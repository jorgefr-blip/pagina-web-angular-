package com.comida.app.Services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.comida.app.Entity.estado;
import com.comida.app.Repository.estadoRepository;

@RestController
@RequestMapping("/estado")
public class estadoService {

    @Autowired()
    private estadoRepository estadoService;

    @GetMapping("/buscar")
    public List<estado> buscar() {
        return estadoService.findAll();
    }

    @PostMapping("/guardar")
    public estado guardar(@RequestBody estado estado) {
        return estadoService.save(estado);
    }

    @DeleteMapping(path="/eliminar/{idestado}")
	public void eliminar(@PathVariable int idestado) {
        estadoService.deleteById(idestado);
	}
}
