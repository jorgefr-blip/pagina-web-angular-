
package com.comida.app.Entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity 
@Table(name="platilloIngrediente")
public class IngredientePlatillo implements Serializable {
	//ID
	private static final long serialVersionUID = 1074759953570315352L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name ="idplatilloIngrediente")
	private Integer idplatilloIngrediente;
	
	@Column(name ="cantidad")
	private Integer cantidad;
	
	@Column(name ="ingredienteIdingrediente")
	private Integer ingredienteIdingrediente;

	@ManyToOne
	@JoinColumn( name = "platilloIdplatillo" )
	@JsonIgnore
	private Platillo platillo;

	public Integer getIdplatilloIngrediente() {
		return idplatilloIngrediente;
	}

	public void setIdplatilloIngrediente(Integer idplatilloIngrediente) {
		this.idplatilloIngrediente = idplatilloIngrediente;
	}

	public Integer getCantidad() {
		return cantidad;
	}

	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}

	public Integer getIngredienteIdingrediente() {
		return ingredienteIdingrediente;
	}

	public void setIngredienteIdingrediente(Integer ingredienteIdingrediente) {
		this.ingredienteIdingrediente = ingredienteIdingrediente;
	}

	public Platillo getPlatillo() {
		return platillo;
	}

	public void setPlatillo(Platillo platillo) {
		this.platillo = platillo;
	}
	
}
