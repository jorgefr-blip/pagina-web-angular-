package com.comida.app.Entity;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table(name="examen")
public class examen implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8587583659277163240L;	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name ="idexamen")
	private Integer idexamen;
	
	@Column(name ="no_PARCIAL")
	private Integer no_PARCIAL;
	
	@Column(name ="fecha_examen")
	private Date fecha_examen;
	
	@Column(name ="nota")
	private Integer nota;
	
	@Column(name ="carnet")
	private String carnet;

	public Integer getIdexamen() {
		return idexamen;
	}

	public void setIdexamen(Integer idexamen) {
		this.idexamen = idexamen;
	}

	public int getNo_PARCIAL() {
		return no_PARCIAL;
	}

	public void setNo_PARCIAL(int no_PARCIAL) {
		this.no_PARCIAL = no_PARCIAL;
	}

	public Date getFecha_examen() {
		return fecha_examen;
	}

	public void setFecha_examen(Date fecha_examen) {
		this.fecha_examen = fecha_examen;
	}

	public Integer getNota() {
		return nota;
	}

	public void setNota(Integer nota) {
		this.nota = nota;
	}

	public String getCarnet() {
		return carnet;
	}

	public void setCarnet(String carnet) {
		this.carnet = carnet;
	}
	
	
}
