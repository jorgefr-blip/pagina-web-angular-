package com.comida.app.Entity;
import java.io.Serializable;  
import java.util.Date;
import java.util.List;
import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity 
@Table(name="pedido")
public class Pedido implements Serializable {
	
	private static final long serialVersionUID = 5794083108786089869L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name ="idpedido")
	private Integer idpedido;
	
	@Column(name ="fechaHora")
	private Date fechaHora;
	
	@Column(name ="total")
	private double total;
	
	@Column(name ="usuarioCorreo")
	private String usuarioCorreo;
	
	@Column(name ="estadoIdestado")
	private Integer estadoIdestado;
	
	@OneToMany(mappedBy="iddetallePedido")
	private List<detallePedido> detallePedidos;  

	public Integer getIdpedido() {
		return idpedido;
	}

	public void setIdpedido(Integer idpedido) {
		this.idpedido = idpedido;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public String getUsuarioCorreo() {
		return usuarioCorreo;
	}

	public void setUsuarioCorreo(String usuarioCorreo) {
		this.usuarioCorreo = usuarioCorreo;
	}

	public Integer getEstadoIdestado() {
		return estadoIdestado;
	}

	public void setEstadoIdestado(Integer estadoIdestado) {
		this.estadoIdestado = estadoIdestado;
	}
	
	
}
