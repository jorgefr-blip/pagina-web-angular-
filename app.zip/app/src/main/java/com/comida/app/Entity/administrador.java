package com.comida.app.Entity;

import java.io.Serializable;      

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table(name="administrador")
public class administrador implements Serializable  {

	private static final long serialVersionUID = -9036468638250709903L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name ="idadministrador")
	private Integer idadministrador;
	
	@Column(name ="usuario")
	private String usuario;
	
	@Column(name ="password")
	private String password;

	@Column(name ="sexo")
	private String sexo;
	
	@Column(name ="tipoAdmin")
	private int tipoAdmin;
	
	public int getTipoAdmin() {
		return tipoAdmin;
	}

	public void setTipoAdmin(int tipoAdmin) {
		this.tipoAdmin = tipoAdmin;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public Integer getIdadministrador() {
		return idadministrador;
	}

	public void setIdadministrador(Integer idadministrador) {
		this.idadministrador = idadministrador;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}