package com.comida.app.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.comida.app.Entity.examen;
import com.comida.app.Repository.examenRepository;

@RestController
@RequestMapping("/examen")
@CrossOrigin
public class examenService {
	
	@Autowired()
    private examenRepository examenRepository;

	@GetMapping("/buscar")
    public List<examen> buscar() {
        return examenRepository.findAll();
    }
    
    @PostMapping("/guardar")
    public examen guardar(@RequestBody examen examen) {
        return examenRepository.save(examen);
    }
    
    @DeleteMapping(path="/eliminar/{idexamen}")
	public void eliminar(@PathVariable int idexamen) {
    	examenRepository.deleteById(idexamen);
	}
   /* @PostMapping(path = "/buscarExamen")
    public examen buscarExamen(@RequestBody examen examen) {
        List<examen> u = examenRepository.findBycarnetoAndNoExamen(examen.getCarnet(), examen.getNo_PARCIAL());
        return u.size() > 0 ? u.get(0) : null;
    }*/
    
}
