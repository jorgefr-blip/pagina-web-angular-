package com.comida.app.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.comida.app.Entity.Producto;

@Repository("ProductoRepository")

public interface ProductoRepository extends JpaRepository<Producto, Integer>{}
