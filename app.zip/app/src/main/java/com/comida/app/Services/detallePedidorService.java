package com.comida.app.Services;
import java.util.List;     
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.comida.app.Entity.detallePedido;
import com.comida.app.Repository.detallePedidoRepository;

@RestController
@RequestMapping("/detallePedido")
@CrossOrigin
public class detallePedidorService {

    @Autowired()
    private detallePedidoRepository detallePedidoRepository;

    @GetMapping("/buscar")
    public List<detallePedido> buscar() {
        return detallePedidoRepository.findAll();
    }

    @PostMapping("/guardar")
    public detallePedido guardar(@RequestBody detallePedido detallePedido) {
        return detallePedidoRepository.save(detallePedido);
    }

    @DeleteMapping(path="/eliminar/{iddetalle_pedido}")
	public void eliminar(@PathVariable int iddetalle_pedido) {
    	detallePedidoRepository.deleteById(iddetalle_pedido);
	}
}
