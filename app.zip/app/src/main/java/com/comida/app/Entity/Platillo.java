package com.comida.app.Entity;
import java.io.Serializable;
import java.util.List;
import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity 
@Table(name="Platillo")
public class Platillo implements Serializable {
	
	private static final long serialVersionUID = -7740172316063004974L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name ="idplatillo")
	private Integer idplatillo;
	
	@Column(name ="foto")
	private String foto;
	
	@Column(name ="precio")
	private double precio;

	@Column(name ="descripcion")
	private String descripcion;
	
	@OneToMany( cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy="platillo" )
	private List<IngredientePlatillo> ingredientePlatillos; 
	
	public List<IngredientePlatillo> getIngredientePlatillos() {
		return ingredientePlatillos;
	}

	public void setIngredientePlatillos(List<IngredientePlatillo> ingredientePlatillos) {
		this.ingredientePlatillos = ingredientePlatillos;
	}

	public Integer getIdplatillo() {
		return idplatillo;
	}

	public void setIdplatillo(Integer idplatillo) {
		this.idplatillo = idplatillo;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
}
