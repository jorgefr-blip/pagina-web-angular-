package com.comida.app.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.comida.app.Entity.CategoriaProducto;
import com.comida.app.Repository.CategoriaProductoRepository;


@RestController
@RequestMapping("/categoriaproducto")
@CrossOrigin
public class CategoriaProductoService {
	
	 @Autowired()
	    private CategoriaProductoRepository CategoriaProductoRepository;
	
	  @GetMapping("/buscar")
	    public List<CategoriaProducto> buscar() {
	        return CategoriaProductoRepository.findAll();
	    }
	  
	  @PostMapping("/guardar")
	    public CategoriaProducto guardar(@RequestBody CategoriaProducto CategoriaProducto) {
	        return CategoriaProductoRepository.save(CategoriaProducto);
	    }
	  @DeleteMapping(path="/eliminar/{idcategoriaProducto}")
		public void eliminar(@PathVariable int idcategoriaProducto) {
		  CategoriaProductoRepository.deleteById(idcategoriaProducto);
		}
}
