package com.comida.app.Services;
import java.util.List;    
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.comida.app.Entity.usuario;
import com.comida.app.Repository.usuarioRepository;

@RestController
@RequestMapping("/usuario")
@CrossOrigin
public class usuarioService {

    @Autowired()
    private usuarioRepository usuarioRepository;

    @GetMapping("/buscar")
    public List<usuario> buscar() {
        return usuarioRepository.findAll();
    }

    @PostMapping("/guardar")
    public usuario guardar(@RequestBody usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public void eliminar(@PathVariable String idusuario) {
    	usuarioRepository.deleteById(idusuario);
    }
    
    @PostMapping("/buscarByNit")
    public List<usuario> buscarByNit(@RequestBody usuario usuario) {
        return usuarioRepository.findByNit(usuario.getNit());
    }    
    @PostMapping(path = "/login")
    public usuario login(@RequestBody usuario usuario) {
        List<usuario> u = usuarioRepository.findByCorreoAndPassword(usuario.getCorreo(), usuario.getPassword());
        return u.size() > 0 ? u.get(0) : null;
    }
    
    @PostMapping("/editar")
    public usuario editar(@RequestBody usuario usuario) {
        return usuarioRepository.save(usuario);
    }
    
}
