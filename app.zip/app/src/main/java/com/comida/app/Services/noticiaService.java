package com.comida.app.Services;
import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.comida.app.Entity.noticia;
import com.comida.app.Repository.noticiaRepository;

@RestController
@RequestMapping("/noticia")
@CrossOrigin
public class noticiaService {
    
    @Autowired()
    private noticiaRepository noticiaRepository;

    @GetMapping("/buscar")
    public List<noticia> buscar() {
        return noticiaRepository.findAll();
    }

    @PostMapping("/guardar")
    public noticia guardar(@RequestBody noticia noticia) {
        return noticiaRepository.save(noticia);
    }

    @DeleteMapping(path="/eliminar/{idnoticia}")
	public void eliminar(@PathVariable int idnoticia) {
    	noticiaRepository.deleteById(idnoticia);
	}
    
    @PostMapping("/buscarByTituloOrDescripcion")
    public List<noticia> buscarByTituloOrFecha(@RequestBody noticia noticia) {
    	return noticiaRepository.findByTituloOrDescripcion(noticia.getTitulo(), noticia.getDescripcion());
    }
    
    @PostMapping("/editar")
    public noticia editar(@RequestBody noticia noticia) {
        return noticiaRepository.save(noticia);
}
}
