package com.comida.app.Services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.comida.app.Entity.TipoAdministrador;

import com.comida.app.Repository.TipoAdministradorRepository;

@RestController
@RequestMapping("/tipoAdministrador")
@CrossOrigin
public class TipoAdministradorService {
	
	@Autowired()
    private TipoAdministradorRepository TipoAdministradorRepository;
	    
	  @GetMapping("/buscar")
	    public List<TipoAdministrador> buscar() {
	        return TipoAdministradorRepository.findAll();
	    }
	  
	  @PostMapping("/guardar")
	    public TipoAdministrador guardar(@RequestBody TipoAdministrador TipoAdministrador) {
	        return TipoAdministradorRepository.save(TipoAdministrador);
	    }
	  
	  @DeleteMapping(path="/eliminar/{idtipoAdministrador}")
		public void eliminar(@PathVariable int idtipoAdministrador) {
		  TipoAdministradorRepository.deleteById(idtipoAdministrador);
		}
}
