package com.comida.app.Entity;

import java.io.Serializable;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table(name="categoria_producto")
public class CategoriaProducto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name ="idcategoriaProducto")
	private Integer idcategoriaProducto;
	
	@Column(name ="nombre")
	private String nombre;

	@Column(name ="imagen")
	private String imagen;

	public Integer getIdcategoriaProducto() {
		return idcategoriaProducto;
	}

	public void setIdcategoriaProducto(Integer idcategoriaProducto) {
		this.idcategoriaProducto = idcategoriaProducto;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
	
}
