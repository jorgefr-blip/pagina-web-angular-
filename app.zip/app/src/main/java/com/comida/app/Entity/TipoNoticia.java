package com.comida.app.Entity;

import java.io.Serializable;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table(name="tipo_noticia")
public class TipoNoticia   implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name ="idtipoNoticia")
	private Integer idtipoNoticia;

	@Column(name ="titulo")
	private String titulo;
	
	@Column(name ="imagen")
	private String imagen;

	public Integer getIdtipoNoticia() {
		return idtipoNoticia;
	}

	public void setIdtipoNoticia(Integer idtipoNoticia) {
		this.idtipoNoticia = idtipoNoticia;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
	
}
