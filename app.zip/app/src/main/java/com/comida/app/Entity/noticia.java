package com.comida.app.Entity;

import java.io.Serializable; 
import java.util.Date;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table(name="noticia")

public class noticia implements Serializable {

	private static final long serialVersionUID = -6881625910386007405L;


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name ="idnoticia")
	private Integer idnoticia;
	
	@Column(name ="titulo")
	private String titulo;
	
	@Column(name ="descripcion")
	private String descripcion;
	
	@Column(name ="fecha")
	private Date fecha;
	
	@Column(name ="imagen")
	private String imagen;

	public Integer getIdnoticia() {
		return idnoticia;
	}

	public void setIdnoticia(Integer idnoticia) {
		this.idnoticia = idnoticia;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

}
