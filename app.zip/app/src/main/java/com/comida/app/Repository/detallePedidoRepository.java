package com.comida.app.Repository;

import org.springframework.data.jpa.repository.JpaRepository; 

import org.springframework.stereotype.Repository;
import com.comida.app.Entity.detallePedido;

@Repository("detallePedidooRepository")
public interface detallePedidoRepository extends JpaRepository<detallePedido, Integer> {

}
