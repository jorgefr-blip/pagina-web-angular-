package com.comida.app.Services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.comida.app.Entity.Pedido;
import com.comida.app.Repository.pedidoRepository;

@RestController
@RequestMapping("/pedido")
@CrossOrigin
public class pedidoService {
	
	@Autowired()
	private pedidoRepository pedidoRepository; 

	@GetMapping(path = "/buscar")
    public List<Pedido> buscar() {
        return pedidoRepository.findAll();
	}
	
	@GetMapping(path = "/buscar/{usuarioCorreo}")
    public List<Pedido> buscarByUsuario(@PathVariable ("usuarioCorreo")  String usuarioCorreo) {
        List<Pedido> ListaPedidos = pedidoRepository.findByUsuarioCorreo(usuarioCorreo);
        return ListaPedidos;
	}
	@PostMapping("/guardar")
    public Pedido guardar(@RequestBody Pedido pedido) {
        return pedidoRepository.save(pedido);
    }
	 @DeleteMapping(path="/eliminar/{idpedido}")
		public void eliminar(@PathVariable int idpedido) {
		 pedidoRepository.deleteById(idpedido);
		}
}