package com.comida.app.Entity;
import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table(name="usuario")
public class usuario implements Serializable  {
    private static final long serialVersionUID = -9036468638250709903L;

	@Id
	@Basic(optional = false)
	@Column(name ="correo")
	private String correo;

    @Column(name ="nombre")
	private String nombre;
	
	@Column(name ="apellido")
	private String apellido;

    @Column(name ="nit")
	private String nit;

    @Column(name ="password")
	private String password;
   
    @Column (name = "fechaRegistro")
    private Date fechaRegistro;

    @Column (name = "edad")
    private Integer edad;
    
    @Column (name = "tipoUsuario")
    private Integer tipoUsuario;
    
    @Column (name = "foto")
    private String foto;
    
    
	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public Integer getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(Integer tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	public Integer getEdad() {
		return edad;
	}

	public void setEdad(Integer edad) {
		this.edad = edad;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

}
