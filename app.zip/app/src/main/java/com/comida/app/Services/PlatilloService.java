package com.comida.app.Services;
import java.util.List;

import com.comida.app.Entity.IngredientePlatillo;
import com.comida.app.Entity.Platillo;
import com.comida.app.Repository.IngredientePlatilloRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.comida.app.Repository.platilloRepository;

@RestController
@RequestMapping("/platillo")
@CrossOrigin
public class PlatilloService  {

	@Autowired()
	private platilloRepository platilloRepository;

    @Autowired
    private IngredientePlatilloRepository IngredientePlatilloRepository;
	
	@GetMapping("/buscar")
    public List<Platillo> buscar() {
        return platilloRepository.findAll();
    }
    @PostMapping("/guardar")
    public Platillo guardar(@RequestBody Platillo platillo) {
        Platillo savedPlatillo = platilloRepository.save(platillo);
        for (IngredientePlatillo ingrediente : savedPlatillo.getIngredientePlatillos()) {
            ingrediente.setPlatillo(savedPlatillo);
            IngredientePlatilloRepository.save(ingrediente);
        }
        return savedPlatillo;
    }
    @DeleteMapping(path="/eliminar/{idplatillo}")
	public void eliminar(@PathVariable int idplatillo) {
        platilloRepository.deleteById(idplatillo);
	}
    @GetMapping("/buscar/{id}")
    public Platillo buscarById(@PathVariable int id) {
        return platilloRepository.findById(id).orElse(null);
    }
    @PostMapping("/editar")
    public Platillo editar(@RequestBody Platillo platillo) {
        return platilloRepository.save(platillo);
}
}
