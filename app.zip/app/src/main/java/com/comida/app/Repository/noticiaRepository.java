package com.comida.app.Repository; 
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository; 
import org.springframework.stereotype.Repository;
import com.comida.app.Entity.noticia;

@Repository("noticiaRepository")
public interface noticiaRepository extends JpaRepository<noticia, Integer>{
	
	public	List<noticia> findByTituloOrDescripcion(String titulo, String descripcion);

}
