package com.comida.app.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.comida.app.Entity.examen;

@Repository("examenRepository")
public interface examenRepository extends JpaRepository<examen, Integer> {
	
	//public	List<examen> findBycarnetoAndNoExamen(String carnet, Integer no_PARCIAL);
	
}
