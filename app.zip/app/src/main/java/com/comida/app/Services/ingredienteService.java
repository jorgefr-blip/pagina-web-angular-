package com.comida.app.Services;
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.comida.app.Entity.ingrediente;
import com.comida.app.Repository.ingredienteRepository;

@RestController
@RequestMapping("/ingrediente")
@CrossOrigin
public class ingredienteService {
        
    @Autowired()
    private ingredienteRepository ingredienteRepository;

    @GetMapping("/buscar")
    public List<ingrediente> buscar() {
        return ingredienteRepository.findAll();
    }
    
    @PostMapping("/guardar")
    public ingrediente guardar(@RequestBody ingrediente ingrediente) {
        return ingredienteRepository.save(ingrediente);
    }
    @DeleteMapping(path="/eliminar/{idingrediente}")
	public void eliminar(@PathVariable int idingrediente) {
    	ingredienteRepository.deleteById(idingrediente);
	}
    @GetMapping("/buscar/{id}")
    public ingrediente buscarById(@PathVariable int id) {
        return ingredienteRepository.findById(id).orElse(null);
    }
    //buscar por nombre y cantidad
    @PostMapping("/buscarBynombreAndCantidad")
    public List<ingrediente> buscarByNombreAndCantidad(@RequestBody ingrediente ingrediente) {
        return ingredienteRepository.findByNombreAndCantidad(ingrediente.getNombre(), ingrediente.getCantidad());
    }

    //buscar por cantidad
    @PostMapping("/buscarBycantidad")
    public List<ingrediente> buscarByCantidad(@RequestBody ingrediente ingrediente) {
        return ingredienteRepository.findByCantidad(ingrediente.getCantidad());
    }
//buscar por like
    @PostMapping("/buscarBynombreLike")
    public List<ingrediente> buscarByNombreLike(@RequestBody ingrediente ingrediente) {
        return ingredienteRepository.findByNombreLike(ingrediente.getNombre());
    }

    @PostMapping("/buscarByNombre")
    public List<ingrediente> buscarByNombre(@RequestBody ingrediente ingrediente) {
        return ingredienteRepository.findByNombre(ingrediente.getNombre());
    }
    
    @PostMapping("/editar")
    public ingrediente editar(@RequestBody ingrediente ingrediente) {
        return ingredienteRepository.save(ingrediente);
    }
}
